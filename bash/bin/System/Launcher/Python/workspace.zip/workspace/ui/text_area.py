import fsui


class TextArea(fsui.TextArea):
    pass
