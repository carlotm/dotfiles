# noinspection PyUnresolvedReferences
from fstd.desktop import *
