# noinspection PyUnresolvedReferences
from fsui.qt.web_view import WebView
