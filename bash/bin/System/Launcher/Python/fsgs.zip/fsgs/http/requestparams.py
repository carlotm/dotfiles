class RequestParams:
    def __init__(self):
        self.platform = ""
        self.game_uuid = ""
        self.state = ""
        self.fullscreen = ""
        self.fullscreen_mode = ""
        self.window_border = ""
