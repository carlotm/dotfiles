from .FSGameSystemContext import FSGameSystemContext


fsgs = FSGameSystemContext()


def default_context():
    return fsgs
