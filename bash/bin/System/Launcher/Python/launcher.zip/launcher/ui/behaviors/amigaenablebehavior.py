from launcher.ui.behaviors.platformbehavior import AmigaEnableBehavior

# FIXME: REMOVE MODULE
