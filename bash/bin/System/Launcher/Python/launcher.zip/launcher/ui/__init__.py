import fsui


def get_screen_size():
    # return 1024, 600
    # return 1366, 768
    return fsui.get_screen_size()
