class Constants:

    TAB_WIDTH = 64
    TAB_HEIGHT = 64

    # COVER_SIZE = (108, 136)
    # SCREEN_SIZE = (224, 140)
    # SCREEN_SIZE = (216, 136)
    SCREEN_SIZE = (210, 134)
    COVER_SIZE = (106, 134)

    # 2 for top border, 1 + 1 for border over and under screens
    # BOTTOM_HEIGHT = SCREEN_SIZE[1] + 20 + + 2 + 1 + 1 + 10
