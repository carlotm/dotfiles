def app_main():
    from launcher.server.game import main

    main()
